"""Exact arithmetic oracle for a quotient/remainder affine-ReLU witness."""
from itertools import product
import json
import random

small_relations = 0
for k in range(3, 9):
    for f in range(1, k-1):
        word, scale = 1 << k, 1 << f
        limit = (word // scale) // 2
        accepted = {}
        for h, n, r in product(range(limit), range(limit + 1), range(scale)):
            if h*n:
                continue
            a = (scale*(h-n) + r) % word
            assert a not in accepted
            accepted[a] = h
            small_relations += 1
        assert len(accepted) == word
        for a, h in accepted.items():
            signed = (a+word//2) % word - word//2
            assert h == max(0, signed//scale)

rng = random.Random(927)
word, scale = 1<<32, 1<<14
cases = [-2**31, -2**31+1, -scale-1,-scale,-1,0,1,scale-1,scale,2**31-1]
cases += [rng.randrange(-2**63,2**63) for i in range(10000)]
for acc in cases:
    signed = (acc+word//2) % word-word//2
    q, r = divmod(signed,scale)
    h,n=max(0,q),max(0,-q)
    carry = ((acc-signed)//word) % word
    lifted = (scale*(h-n)+r+word*carry) % (word*word)
    assert lifted == acc%(word*word)
    assert h*n == 0 and 0<=h<2**17 and 0<=n<=2**17
    assert h==max(0,signed//scale)
for i in range(10000):
    a=rng.randrange(-2**30,2**30)
    noise=rng.randrange(scale)
    q,r=divmod(a+noise,scale)
    h,n=max(0,q),max(0,-q)
    assert scale*(h-n)+r-noise==a
    assert h==max(0,(a+noise)//scale)
print(json.dumps({'small_valid_relations':small_relations,'wrap_and_boundary_fixtures':len(cases),
                  'bounded_stochastic_fixtures':10000}))
