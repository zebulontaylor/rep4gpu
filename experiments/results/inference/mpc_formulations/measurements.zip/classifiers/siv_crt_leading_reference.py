"""Run the four-point matrix gate on the trained SIV residue-lane fixtures."""
from pathlib import Path
import hashlib

# Reuse the temporary residue input, uniform mask and private sign protocol.
source = Path('/tmp/siv-edge-research-20261118/crt_protocol_carry.py').read_text()
exec(source[:source.index("\nrun('unscaled_text_classifier'")])

def product(party, x, w, operation):
    node = party.party
    owners = [(node + offset) % 4 for offset in (1, 2, 3)]
    fx = sum((node-owner)*value for owner,value in zip(owners,x.parts)) % party.primes
    fw = sum((node-owner)*value for owner,value in zip(owners,w.parts)) % party.primes
    masked = operation(fx,fw) % party.primes
    output_parts = []
    for owner in owners:
        constant = party._random(owner, masked.shape, x.device)
        slope = party._random(owner, masked.shape, x.device)
        masked = (masked + (node-owner)*(constant+node*slope)) % party.primes
        output_parts.append((-slope) % party.primes)
    # Two exchanges give identical ordered transcripts on the honest-run fixture.
    # This harness does not implement Byzantine agreement on abort.
    data = masked.to(torch.uint8).numpy().tobytes()
    receipts = party.transport.exchange({peer:data for peer in range(4) if peer!=node})
    receipts[node] = data
    ordered = [receipts[peer] for peer in range(4)]
    digest = hashlib.sha256(b''.join(ordered)).digest()
    verdicts = party.transport.exchange({peer:digest for peer in range(4) if peer!=node})
    if any(value != digest for peer,value in verdicts.items() if peer != node):
        raise ValueError('broadcast views differ')
    y = [torch.from_numpy(np.frombuffer(value,np.uint8).copy()).reshape(masked.shape).long() for value in ordered]
    assert torch.all((y[3]-3*y[2]+3*y[1]-y[0]) % party.primes == 0)
    inv2 = (party.primes+1)//2
    leading = ((y[0]-2*y[1]+y[2])*inv2) % party.primes
    if 0 in owners:
        i = owners.index(0)
        output_parts[i]=(output_parts[i]+leading) % party.primes
    return Share(tuple(output_parts))

Odd.edges=product
run('unscaled_text_classifier',[251,241,239,233],32)
run('tiny_ring16_fixed_head',[251,241],32)
