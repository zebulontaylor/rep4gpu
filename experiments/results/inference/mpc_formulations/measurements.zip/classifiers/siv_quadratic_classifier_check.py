"""Check two exact quadratic rewrites of the small trained SIV classifier."""
from pathlib import Path
import json
import numpy as np

checkpoint = Path("experiments/results/examples/tiny_ring16_fixed_head/model.npz")
with np.load(checkpoint) as data:
    w, b, c, signs, x = (data[k].astype(np.int64) for k in ("w1", "b1", "b2", "signs", "x_test"))
q = (w * signs) @ w.T
linear = 2 * w @ (signs * b)
constant = (b * b) @ signs + c[0]
reference = ((x @ w + b) ** 2) @ signs + c[0]

def public_binary_score(row):
    active = np.flatnonzero(row)
    pair_values = np.triu(q[np.ix_(active, active)], 1)
    return constant + (q.diagonal()[active] + linear[active]).sum() + 2 * pair_values.sum()

assert np.array_equal([public_binary_score(row) for row in x], reference)
ring = 2**16
r = np.random.default_rng(42).integers(ring, size=x.shape, dtype=np.int64)
difference = (x - r) % ring
slope = (2 * (r @ q) + linear) % ring
offset = ((r * ((r @ q) % ring)).sum(axis=1) + r @ linear + constant) % ring
translated = ((difference * ((difference @ q) % ring)).sum(axis=1)
              + (difference * slope).sum(axis=1) + offset) % ring
assert np.array_equal(translated, reference % ring)
counts = x.sum(axis=1)
print(json.dumps(dict(exact_scores=int(x.shape[0]), features=int(w.shape[0]),
                      hidden=int(w.shape[1]), median_selected_coefficients=float(np.median(counts*(counts+1)//2)),
                      max_absolute_score=int(np.max(np.abs(reference))))))
