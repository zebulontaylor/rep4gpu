"""Temporary checked CPU prototype of residue-lane classification."""
from pathlib import Path
import hashlib, itertools, math, concurrent.futures as ft, json
import numpy as np, torch
from rep4gpu.protocol.runtime import SCHEDULE, Party, make_seeds, Share
from rep4gpu.arithmetic.conversion import a2b
from rep4gpu.protocol.transport import IdealNetwork
torch.set_num_threads(1)
class Odd(Party):
    def __init__(self,i,transport,keys,qs):
        super().__init__(i,transport,keys,bits=32,binary_bits=32)
        self.qs=qs
        self.primes=torch.tensor(qs,dtype=torch.int64)
    def _normalize(self,value,binary=False):
        assert not binary
        return value % self.primes
    def _wire_bits(self,binary):assert not binary;return 8
    def _random(self,excluded,shape,device,binary=False):
        assert not binary and shape[-1]==len(self.qs)
        nonce,=self._reserve_nonces([excluded])
        n=math.prod(shape[:-1])
        values=[]
        for q in self.qs:
            # Distinct lanes and draws have distinct input strings. Reject high octets to sample uniformly modulo q.
            prefix=b'SIV-research-crt-mask-v1'+self.seeds[excluded]+bytes([excluded,q])+nonce.to_bytes(8,'big')
            stream=hashlib.shake_256(prefix)
            count=math.ceil(n*256/q)+256
            while True:
                raw=np.frombuffer(stream.digest(count),np.uint8)
                accepted=raw[raw<q]
                if len(accepted)>=n:break
                count*=2
            values.append(accepted[:n])
        return torch.from_numpy(np.stack(values,axis=-1).reshape(shape)).to(torch.int64)
    def edges(self,a,b,op):
        x0,x1,x2=a.parts;w0,w1,w2=b.parts
        loc=[None]*5
        loc[(self.party-1)%4]=op(x0+x1,w0+w1)
        loc[self.party]=op(x1+x2,w1+w2)
        loc[4]=op(x0-x2,w2-w0)
        return self._reshare_product(loc,False,a.device)
def mat(a,b):return (a.movedim(-1,0)@b.movedim(-1,0)).movedim(0,-1)
def private_sign(p,wide,lane_share):
    qs=p.qs;M=math.prod(qs)
    coeff=torch.tensor([(M//q)*pow(M//q,-1,q) for q in qs],dtype=torch.int64)
    parts={e:(v*coeff).sum(-1)%M for e,v in zip(((p.party+j+1)%4 for j in range(3)),lane_share.parts)}
    from rep4gpu.gpu.bits.carry_tree import carry_bits
    shape=next(iter(parts.values())).shape
    nbits=M.bit_length(); L=1<<nbits
    specs=[]
    for left,right,sender,backup,recv,out in [(0,1,2,3,0,1),(2,3,0,1,2,3)]:
        v=None
        if p.party in (sender,backup):
            v=2*(parts[left]+parts[right])%M
            if left==2:v+=L-M
        specs.append((sender,backup,recv,out,v))
    u,vshift=wide.joint_input_batch(specs,shape=shape,binary=True)
    lsb=Share(tuple((a^b)&1 for a,b in zip(u.parts,vshift.parts)),True)
    carry=carry_bits(wide,u,vshift,[nbits])[0]
    return wide.open(wide.xor(lsb,carry))
def run(case,qs,bits):
    root=Path('/home/zeb/Desktop/SIV/experiments/results/examples')
    d=np.load(root/case/'model.npz')
    model={name:torch.from_numpy(d[name]).to(torch.int64) for name in ('x_test','w1','b1','b2')}
    fixed='w2' not in d
    head=torch.from_numpy(d['signs' if fixed else 'w2']).to(torch.int64).reshape(-1,1)
    true=(((model['x_test']@model['w1']+model['b1'])**2)@head+model['b2'])>=0
    kn,ks=make_seeds(),make_seeds(); n1,n2=IdealNetwork(timeout=180),IdealNetwork(timeout=180)
    def worker(i):
        p=Odd(i,n1.endpoint(i),{e:v for e,v in kn.items() if e!=i},qs)
        w=Party(i,n2.endpoint(i),{e:v for e,v in ks.items() if e!=i},bits=bits,binary_bits=bits)
        def inp(owner,value):
            vals=value[...,None]%p.primes if i==owner else None
            return p.input(owner,vals,(*value.shape,len(qs)))
        # In this functional experiment all four role threads share a process. Per-role arrays are scoped to their actual owner at protocol entry.
        weights,bias,bias2=[inp(1,model[k]) for k in ('w1','b1','b2')]
        hweight=None if fixed else inp(1,head)
        x=inp(0,model['x_test'])
        setupbytes,setuprounds=p.transport.bytes_sent,p.transport.round
        hidden=p.add(p.edges(x,weights,mat),bias)
        if fixed:
            def combine(a,b): return ((a*b)*head.reshape(1,-1,1)).sum(1,keepdim=True)
            score=p.add(p.edges(hidden,hidden,combine),bias2)
        else:
            square=p.edges(hidden,hidden,torch.mul)
            score=p.add(p.edges(square,hweight,mat),bias2)
        output=private_sign(p,w,score)
        assert torch.equal(output,true.to(torch.int64))
        return setupbytes,p.transport.bytes_sent-setupbytes,w.transport.bytes_sent,setuprounds,p.transport.round-setuprounds,w.transport.round
    with ft.ThreadPoolExecutor(4) as pool: rows=list(pool.map(worker,range(4)))
    print(json.dumps(dict(case=case,examples=true.numel(),qs=qs,fully_checked_labels=True,global_setup_bytes=sum(r[0] for r in rows),arithmetic_bytes=sum(r[1] for r in rows),sign_and_open_bytes=sum(r[2] for r in rows),rounds=[rows[0][3],rows[0][4],rows[0][5]])),flush=True)
run('unscaled_text_classifier',[251,241,239,233],32)
run('tiny_ring16_fixed_head',[251,241],32)
