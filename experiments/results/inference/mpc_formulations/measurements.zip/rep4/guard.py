import torch,triton,triton.language as tl,statistics,json
from rep4gpu.gpu.matmul.kernels import CompactWeight,_tensor_mm
from rep4gpu.gpu.matmul.strassen_kernels import prepare_strassen_weight,ring_matmul_strassen
MASK=(1<<33)-1
@triton.jit
def _leaf(A,B,C,M:tl.constexpr,N:tl.constexpr,K:tl.constexpr,BM:tl.constexpr,BN:tl.constexpr,BK:tl.constexpr):
    j=tl.program_id(2)
    _tensor_mm(A+j*M*K,B+j*K*N,C+j*M*N,M,N,K,40,BM,BN,BK,False)
def splitw(b):
    r,c=b.shape;m=r//2;n=c//2
    a,b1,c1,d=b[:m,:n],b[:m,n:],b[m:,:n],b[m:,n:]
    return torch.stack((a+d,a,b1-d,c1-a,d,a+b1,c1+d))
def splitx(x):
    r,c=x.shape;m=r//2;n=c//2
    a,b,c,d=x[:m,:n],x[:m,n:],x[m:,:n],x[m:,n:]
    return torch.stack((a+d,c+d,a,d,a+b,c-a,b-d))
def join(p):
    a,b,c,d,e,f,g=p.unbind()
    return torch.cat((torch.cat((a+d-e+g,c+e),1),torch.cat((b+d,a-b+c+f),1)),0)&MASK
def guard(g,w,m,k,n,level):
    if level:
        g=splitx(g);m,k,n=m//2,k//2,n//2;batch=7
    else:batch=1
    out=torch.empty((batch,m,n),dtype=torch.int64,device='cuda')
    _leaf[(triton.cdiv(m,32),triton.cdiv(n,128),batch)](g,w,out,m,n,k,32,128,64,num_warps=4,num_stages=1)
    return join(out) if level else out[0]&MASK
def run(m,k,n):
    torch.manual_seed(4148)
    xs=[torch.randint(0,1<<32,(m,k),device='cuda',dtype=torch.int64) for _ in range(3)]
    ws=[torch.randint(-(1<<31),1<<31,(k,n),device='cuda',dtype=torch.int32) for _ in range(3)]
    edge=[prepare_strassen_weight(CompactWeight(w)) for w in (ws[0]+ws[1],ws[1]+ws[2],ws[2]-ws[0])]
    def edge3():return tuple(ring_matmul_strassen(x,w) for x,w in zip((xs[0]+xs[1],xs[1]+xs[2],xs[0]-xs[2]),edge))
    def eval0(ws):return (-ws[0]-2*ws[1]-3*ws[2])&MASK
    W=eval0([w.long()&0xffffffff for w in ws]);cache=splitw(W)
    def direct():return guard(eval0(xs),W,m,k,n,0)
    def strassen():return guard(eval0(xs),cache,m,k,n,1)
    gr=direct();gs=strassen()
    assert torch.equal(gr,gs)
    rows=[0,m//4,m//2,m-1];cols=[0,n//4,n//2,n-1]
    F=eval0([x[rows].cpu() for x in xs])
    G=eval0([w[:,cols].cpu().long()&0xffffffff for w in ws])
    assert torch.equal(gr[rows][:,cols].cpu(),(F@G)&MASK)
    graphs=[]
    for fn in (edge3,direct,strassen):
        fn()
        g=torch.cuda.CUDAGraph()
        with torch.cuda.graph(g): o=fn()
        graphs.append(g)
    times=[[] for _ in graphs]
    for rep in range(9):
        order=[0,1,2] if rep%2==0 else [2,1,0];order=order[rep%3:]+order[:rep%3]
        for i in order:
            g=graphs[i]
            for _ in range(3):g.replay()
            a,b=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
            a.record()
            for _ in range(10):g.replay()
            b.record();b.synchronize();times[i].append(a.elapsed_time(b)/10)
    print(json.dumps(dict(shape=[m,k,n],device=torch.cuda.get_device_name(),columns=['three_signed_edges_strassen32','guard33_direct','guard33_strassen'],median_ms=[statistics.median(x) for x in times],raw_ms=times,full_direct_strassen_agreement=True,cpu_oracle_coordinates=len(rows)*len(cols))),flush=True)
for k,n in ((2048,8192),(8192,2048)):run(128,k,n)
