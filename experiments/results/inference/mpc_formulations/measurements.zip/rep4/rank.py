from itertools import product,combinations
def matrix(coords):
    return sum(1<<(3*i+j) for i,j in coords)
targets=[matrix([(0,0),(0,1),(1,0)]),matrix([(1,1),(1,2),(2,1)]),matrix([(0,2),(2,0)])]
rankone=[matrix((i,j) for i in range(3) for j in range(3) if (a>>i)&(b>>j)&1) for a in range(1,8) for b in range(1,8)]
assert len(set(rankone))==49
count=0
for choice in combinations(rankone,4):
    a,b,c,d=choice
    s={0,a,b,c,d,a^b,a^c,a^d,b^c,b^d,c^d,a^b^c,a^b^d,a^c^d,b^c^d,a^b^c^d}
    assert not all(t in s for t in targets), choice
    count+=1
print(f'All {count} four-subsets of {len(rankone)} rank-one matrices over GF(2) fail to span the three original local outputs. Hence intact output tuple has bilinear rank at least five over each power-of-two ring.')
