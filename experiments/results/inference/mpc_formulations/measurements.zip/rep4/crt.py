"""Functional CRT classifier oracle and an eager Rep4 final-label check."""
import concurrent.futures as ft
import itertools, math, json
from pathlib import Path
import numpy as np
import torch
from rep4gpu.protocol.runtime import SCHEDULE, Party, make_seeds, Share
from rep4gpu.protocol.transport import IdealNetwork

root=Path('/home/zeb/Desktop/SIV/experiments/results/examples')
rng=np.random.default_rng(8109721)
torch.set_num_threads(1)
def share(x,p):
    z=rng.integers(p,size=(3,*x.shape),dtype=np.int64)
    return [*z,(x-z.sum(axis=0))%p]
def reshape_slot(x):
    return [z.reshape(-1,1) for z in x]
def edge_product(x,y,q,op):
    # Ideal arithmetic for the six authenticated joint inputs.
    accum=None
    for sender,backup,receiver,outsider in SCHEDULE:
        i,j=sorted((receiver,outsider))
        plus=(j-i)%2 == 1
        val=(op((x[i]+x[j])%q,(y[i]+y[j])%q) if plus else op((x[i]-x[j])%q,(y[j]-y[i])%q))%q
        if accum is None: accum=np.zeros((4,*val.shape),dtype=np.int64)
        r=rng.integers(q,size=val.shape,dtype=np.int64)
        accum[receiver]+=r
        accum[outsider]+=val-r
    return [v%q for v in accum]
def expand(r,s):return [a+b for a,b in zip(r,s)]
def residues(model,q):
    x,w,b=(model[k].astype(np.int64) for k in ('x_test','w1','b1'))
    h=expand(edge_product(share(x,q),share(w,q),q,np.matmul),share(b,q))
    sq=edge_product(h,h,q,np.multiply)
    if 'w2' in model:
        s=edge_product(sq,share(model['w2'].astype(np.int64),q),q,np.matmul)
    else:
        s=[(a @ model['signs'].astype(np.int64).reshape(-1,1))%q for a in sq]
    return expand(s,share(model['b2'].astype(np.int64),q))
def crt_component(res,qs,M):
    return sum((x%p)*(M//p)*pow(M//p,-1,p) for x,p in zip(res,qs))%M
def secure_class(parts,M,bits):
    # A batched non-wrapping subtraction suffices for all seven thresholds.
    h=M//2
    ts=torch.tensor([h+1,M,M+h+1,2*M,2*M+h+1,3*M,3*M+h+1],dtype=torch.int64)[:,None]
    weights=torch.tensor([1,-1,1,-1,1,-1,1],dtype=torch.int64)[:,None]
    seeds,net=make_seeds(),IdealNetwork()
    def worker(i):
        party=Party(i,net.endpoint(i),{e:v for e,v in seeds.items() if e!=i},bits=bits,binary_bits=bits)
        shared=Share(tuple(torch.from_numpy(parts[(i+j+1)%4]).reshape(1,-1).expand(7,-1) for j in range(3)))
        less=party.sign_bit(party.sub(shared,party.public(ts,like=shared)))
        label=Share(tuple((v*weights).sum(0) for v in less.parts))
        label=party.open(label)
        return label,party.transport.bytes_sent,party.transport.round
    with ft.ThreadPoolExecutor(4) as pool:
        rows=list(pool.map(worker,range(4)))
    assert all(torch.equal(rows[0][0],r[0]) for r in rows)
    return rows[0][0].numpy(),sum(r[1] for r in rows),rows[0][2]

def secure_class_fast(parts,M,bits):
    from rep4gpu.arithmetic.conversion import a2b
    seeds,net=make_seeds(),IdealNetwork()
    shape=parts[0].shape
    def worker(i):
        party=Party(i,net.endpoint(i),{e:v for e,v in seeds.items() if e!=i},bits=bits,binary_bits=bits)
        held={e:torch.from_numpy(v) for e,v in enumerate(parts) if e!=i}
        specs=[]
        for left,right,sender,backup,recv,out in [(0,1,2,3,0,1),(2,3,0,1,2,3)]:
            val=(2*(held[left]+held[right]))%M if i in (sender,backup) else None
            specs.append((sender,backup,recv,out,val))
        u,v=party.joint_input_batch(specs,shape=shape)
        total=party.add(u,v)
        low=Share(tuple(a&1 for a in total.parts),True)
        diff=party.sub(party.public(M-1,like=total),total)
        bitword=a2b(party,diff)
        carry=Share(tuple((a>>(bits-1))&1 for a in bitword.parts),True)
        nonneg=party.xor(party.public(1,like=low),party.xor(low,carry))
        label=party.open(nonneg).reshape(-1)
        return label,party.transport.bytes_sent,party.transport.round
    with ft.ThreadPoolExecutor(4) as pool:
        rows=list(pool.map(worker,range(4)))
    assert all(torch.equal(rows[0][0],r[0]) for r in rows)
    return rows[0][0].numpy(),sum(r[1] for r in rows),rows[0][2]

for case,qs,bits in [('unscaled_text_classifier',[251,241,239,233],64),('tiny_ring16_fixed_head',[251,241],32)]:
    model=np.load(root/case/'model.npz'); M=math.prod(qs)
    h=model['x_test'].astype(np.int64) @ model['w1'].astype(np.int64) + model['b1']
    w=model['w2'] if 'w2' in model else model['signs']
    exact=((h*h) @ w.astype(np.int64).reshape(-1,1)+model['b2']).ravel()
    rs=[residues(model,q) for q in qs]
    parts=[crt_component(rr,qs,M) for rr in zip(*rs)]
    x=(sum(parts)%M).ravel()
    score=np.where(x>M//2,x-M,x)
    assert np.array_equal(score,exact)
    labels,wire,rounds=secure_class(parts,M,bits)
    assert np.array_equal(labels,score>=0)
    fast_labels,fast_wire,fast_rounds=secure_class_fast(parts,M,bits)
    assert np.array_equal(fast_labels,score>=0)
    print(json.dumps(dict(model=case,examples=len(exact),qs=qs,exact_scores_and_labels=True,fast_sign_bytes=fast_wire,fast_sign_rounds=fast_rounds,sign_gate_bytes=wire,sign_gate_rounds=rounds,reference_min=int(exact.min()),reference_max=int(exact.max()))),flush=True)
