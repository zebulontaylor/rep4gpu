#!/bin/sh
set -eu
cd /home/zeb/Desktop/SIV
export PYTHONPATH=/home/zeb/Desktop/SIV
export EDGE_COMPARE="$1"
exec .venv/bin/python /tmp/siv-edge-research-20261118/decode.py --batch 1 --width 2048 --bits 32 --binary-bits 32 --fractional-bits 14 --prepared --weight-storage words32 --optimized --gpu-open --rounding probabilistic --bounded-sign --phase-graphs --graph-check-at-send --repeats 9 --output "/tmp/siv-edge-research-20261118/decode-$EDGE_COMPARE${2:-}.json"
