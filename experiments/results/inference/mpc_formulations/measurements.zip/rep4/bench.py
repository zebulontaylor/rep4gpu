import torch,triton,statistics,json
from rep4gpu.gpu.matmul.kernels import prepare_weight,CompactWeight
from rep4gpu.gpu.matmul.strassen_kernels import prepare_strassen_weight,local_products_strassen,ring_matmul_strassen
from rep4gpu.gpu.matmul.tuned_kernels import ring_matmul_tuned
def run(m,k,n):
    torch.manual_seed(112+n)
    xs=[torch.randint(-2**63,2**63-1,(m,k),device='cuda',dtype=torch.int64) for _ in range(3)]
    ys=[CompactWeight(torch.randint(-2**31,2**31-1,(k,n),device='cuda',dtype=torch.int32)) for _ in range(3)]
    s=[prepare_strassen_weight(y) for y in ys]
    ab,bc,ac=[CompactWeight(w) for w in (ys[0].words+ys[1].words,ys[1].words+ys[2].words,ys[2].words-ys[0].words)]
    t=[prepare_strassen_weight(y) for y in (ab,bc,ac)]
    def base():
        return local_products_strassen(xs,s,opaque=True)
    def edge_compact():
        return ring_matmul_tuned(xs[0]+xs[1],ab,32),ring_matmul_tuned(xs[1]+xs[2],bc,32),ring_matmul_tuned(xs[0]-xs[2],ac,32)
    def edge_strassen():
        return tuple(ring_matmul_strassen(a,b) for a,b in zip((xs[0]+xs[1],xs[1]+xs[2],xs[0]-xs[2]),t))
    outputs=edge_compact()
    for got,want in zip(edge_strassen(),outputs):
        assert torch.equal(got,want)
    # Independent CPU oracle on full-K selected output coordinates.
    rr=[0,m-1,m//2]; cc=[n//2,0,n-1]
    x=[w[rr].cpu() for w in xs]; y=[w.words[:,cc].to('cpu',torch.int64) for w in ys]
    expected=[(x[0]+x[1])@(y[0]+y[1]),(x[1]+x[2])@(y[1]+y[2]),(x[0]-x[2])@(y[2]-y[0])]
    for got,want in zip(outputs,expected):
        assert torch.equal(got[rr][:,cc].cpu(),want&0xffffffff)
    names=['baseline_strassen','edge_compact','edge_strassen']
    graphs=[]
    for f in (base,edge_compact,edge_strassen):
        f()
        graph=torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            out=f()
        graphs.append(graph)
    samples={name:[] for name in names}
    for rep in range(9):
        order=list(range(3))
        if rep%2: order.reverse()
        order=order[(rep//2)%3:]+order[:(rep//2)%3]
        for i in order:
            for _ in range(3): graphs[i].replay()
            start,end=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
            start.record()
            for _ in range(10): graphs[i].replay()
            end.record();end.synchronize()
            samples[names[i]].append(start.elapsed_time(end)/10)
    print(json.dumps(dict(device=torch.cuda.get_device_name(),shape=[m,k,n],medians={k:statistics.median(v) for k,v in samples.items()},raw=samples)),flush=True)
for k,n in ((2048,8192),(8192,2048)):
    run(128,k,n)
