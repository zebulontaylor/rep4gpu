import os, sys
from threadpoolctl import threadpool_limits
from rep4gpu.gpu.matmul import strassen_kernels as sk
from rep4gpu.gpu.matmul.kernels import CompactWeight
from rep4gpu.models.device_inference import DeviceInferenceParty
from rep4gpu.protocol.runtime import PreparedMatrix
from experiments.benchmarks.inference.device_inference import main
from pathlib import Path
import torch
import json, hashlib
baseline = os.getenv("EDGE_COMPARE","candidate") == "baseline"
if not baseline:
    def prepare(self,weight,*,storage):
        assert storage=="strassen32" and self.bits==32
        x0,x1,x2=(w.to(torch.int32) for w in weight.parts)
        return PreparedMatrix(tuple(sk.prepare_strassen_weight(CompactWeight(l-r if sub else l+r))
                                    for l,r,sub in ((x0,x1,False),(x1,x2,False),(x2,x0,True))))
    def products(xs,weights,*,opaque):
        return tuple(sk.ring_matmul_strassen(x,y) for x,y in zip(
                        (xs[0]+xs[1],xs[1]+xs[2],xs[0]-xs[2]), weights))
    DeviceInferenceParty.prepare_weight_share = prepare
    sk.local_products_strassen = products
path=Path(sys.argv[sys.argv.index("--output")+1])
with threadpool_limits(limits=1,user_api='blas'): main()
report=json.loads(path.read_text())
report['variant']='baseline' if baseline else 'temporary signed-edge Strassen'
report['prototype_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
if not baseline:
    report['results'][0]['local_matmul_backend']='signed-edge three single-product Strassen calls'
path.write_text(json.dumps(report,indent=2)+'\n')
