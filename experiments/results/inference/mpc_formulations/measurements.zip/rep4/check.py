import concurrent.futures as ft
import itertools
import torch
from rep4gpu.protocol.runtime import Party, make_seeds, Share, SCHEDULE
from rep4gpu.protocol.transport import IdealNetwork

torch.set_num_threads(1)
def product(p, a, b):
    x0,x1,x2 = a.parts
    w0,w1,w2 = b.parts
    local = [None]*5
    local[(p.party - 1) % 4] = (x0+x1) @ (w0+w1)
    local[p.party] = (x1+x2) @ (w1+w2)
    local[4] = (x0-x2) @ (w2-w0)
    return p._reshare_product(local, False, a.device)

def run(bits, a, b, fault=None):
    keys, net = make_seeds(), IdealNetwork()
    def worker(i):
        p = Party(i, net.endpoint(i), {j:keys[j] for j in range(4) if j != i}, bits=bits)
        wrap = lambda v: v if bits == 64 else v & (2**bits-1)
        share = lambda parts: Share(tuple(wrap(parts[(i+j+1)%4]) for j in range(3)))
        if fault:
            sender, recv = fault
            exchange = p.transport.exchange
            def corrupt(out):
                if i == sender:
                    bad = bytearray(out[recv])
                    bad[0] ^= 1
                    out = dict(out)
                    out[recv] = bytes(bad)
                return exchange(out)
            p.transport.exchange = corrupt
        try:
            c = product(p, share(a), share(b))
        except ValueError as e:
            assert "hash mismatch" in str(e)
            return False
        if fault:
            return True
        size = p.transport.bytes_sent
        result = wrap(p.open(c))
        return result, size, c.parts
    with ft.ThreadPoolExecutor(4) as pool:
        rows = list(pool.map(worker, range(4)))
    if fault:
        assert rows == [i != fault[1] for i in range(4)], (fault,rows)
        return
    expected = sum(a) @ sum(b)
    if bits != 64:
        expected &= 2**bits - 1
    assert all(torch.equal(row[0],expected) for row in rows)
    assert sum(row[1] for row in rows) == 6*expected.numel()*(bits//8)+192
    for excluded in range(4):
        copies = [rows[p][2][(excluded-p-1)%4] for p in range(4) if p!=excluded]
        assert all(torch.equal(copies[0], copy) for copy in copies)

for i,j in itertools.product(range(4), repeat=2):
    a=[torch.tensor([[int(k==i)]]) for k in range(4)]
    b=[torch.tensor([[int(k==j)]]) for k in range(4)]
    run(32,a,b)
g=torch.Generator().manual_seed(20261118)
for bits,shapes in itertools.product((16,32,64), ((1,7,11),(3,5,4),(5,17,9))):
    m,k,n=shapes
    for _ in range(3):
        a=[torch.randint(-2**63,2**63-1,(m,k),generator=g) for i in range(4)]
        b=[torch.randint(-2**63,2**63-1,(k,n),generator=g) for i in range(4)]
        run(bits,a,b)
for sender,backup,receiver,outsider in SCHEDULE:
    run(32,a,b,fault=(sender,receiver))
print("passed: all 16 ordered component monomials, 27 randomized rectangular matrix cases at widths 16/32/64, all replica copies, exact single-exchange byte counts, six sender-payload corruption probes")
