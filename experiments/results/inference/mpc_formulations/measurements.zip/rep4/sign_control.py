from rep4gpu.protocol.runtime import Party, make_seeds, Share
from rep4gpu.protocol.transport import IdealNetwork
from rep4gpu.models.text_classifier import nonnegative_label
from concurrent.futures import ThreadPoolExecutor
import torch,json
torch.set_num_threads(1)
for bits in (32,16):
    data=torch.arange(-512,513,dtype=torch.int64).reshape(-1,1)
    seeds=make_seeds();net=IdealNetwork()
    def one(i):
        p=Party(i,net.endpoint(i),{x:v for x,v in seeds.items() if x!=i},bits=bits,binary_bits=32)
        x=p.input(1,data if i==1 else None,data.shape)
        start=p.transport.bytes_sent;round0=p.transport.round
        label=p.open(nonnegative_label(p,x))
        assert torch.equal(label,data>=0)
        return p.transport.bytes_sent-start,p.transport.round-round0
    with ThreadPoolExecutor(4) as pool: r=list(pool.map(one,range(4)))
    print(json.dumps(dict(bits=bits,score_count=data.numel(),sign_and_open_bytes=sum(x[0] for x in r),rounds=r[0][1])))
