import torch,triton,triton.language as tl, statistics, json
from rep4gpu.gpu.matmul.kernels import CompactWeight
from rep4gpu.gpu.matmul.tuned_kernels import ring_matmul_tuned,local_products_tuned

@triton.jit
def _prime_edges(X,Y,Z,M:tl.constexpr,K:tl.constexpr,N:tl.constexpr,BM:tl.constexpr,BN:tl.constexpr,BK:tl.constexpr):
    b=tl.program_id(2)
    lane=b%4
    edge=b//4
    p=tl.where(lane==0,251,tl.where(lane==1,241,tl.where(lane==2,239,233)))
    h=p>>1
    first=tl.where(edge==1,1,0)
    second=tl.where(edge==0,1,2)
    r=tl.program_id(0)*BM+tl.arange(0,BM)
    c=tl.program_id(1)*BN+tl.arange(0,BN)
    kk=tl.arange(0,BK)
    acc=tl.full((BM,BN),0,tl.int32)
    for start in range(tl.cdiv(K,BK)):
        k=kk+start*BK
        ai=r[:,None]*K+k[None,:]
        valid=(r[:,None]<M)&(k[None,:]<K)
        x=tl.load(X+(first*4+lane)*M*K+ai,valid,0).to(tl.int32)
        y=tl.load(X+(second*4+lane)*M*K+ai,valid,0).to(tl.int32)
        a=tl.where(edge==2,x-y,x+y)
        a=tl.where(a>h,a-p,tl.where(a< -h,a+p,a)).to(tl.int8)
        w=tl.load(Y+b*K*N+k[:,None]*N+c[None,:],(k[:,None]<K)&(c[None,:]<N),0)
        acc=tl.dot(a,w,acc,out_dtype=tl.int32)
    val=acc%p
    val=tl.where(val<0,val+p,val).to(tl.uint8)
    tl.store(Z+b*M*N+r[:,None]*N+c[None,:],val,(r[:,None]<M)&(c[None,:]<N))


@triton.jit
def _word_edges(X0,X1,X2,W0,W1,W2,OUT,M:tl.constexpr,K:tl.constexpr,N:tl.constexpr,BM:tl.constexpr,BN:tl.constexpr,BK:tl.constexpr):
    e=tl.program_id(2)
    if e==0:
        A=X0;A2=X1;B=W0
    elif e==1:
        A=X1;A2=X2;B=W1
    else:
        A=X0;A2=X2;B=W2
    r=tl.program_id(0)*BM+tl.arange(0,BM)
    c=tl.program_id(1)*BN+tl.arange(0,BN)
    kk=tl.arange(0,BK)
    out=tl.full((BM,BN),0,tl.uint32)
    for start in range(tl.cdiv(K,BK)):
        k=kk+start*BK; ai=r[:,None]*K+k[None,:]; valid=(r[:,None]<M)&(k[None,:]<K)
        x=tl.load(A+ai,valid,0).to(tl.uint32); y=tl.load(A2+ai,valid,0).to(tl.uint32)
        a=tl.where(e==2,x-y,x+y)+0x80808080
        b=tl.load(B+k[:,None]*N+c[None,:],(k[:,None]<K)&(c[None,:]<N),0).to(tl.uint32)+0x80808080
        for d in tl.static_range(4):
            acc=tl.full((BM,BN),0,tl.int32)
            for i in tl.static_range(d+1):
                aa=(((a>>(8*i))&255).to(tl.int32)-128).to(tl.int8)
                bb=(((b>>(8*(d-i)))&255).to(tl.int32)-128).to(tl.int8)
                acc=tl.dot(aa,bb,acc,out_dtype=tl.int32)
            out=tl.inline_asm_elementwise("add.u32 $0, $1, $2;", constraints="=r,r,r",args=[out,acc.to(tl.uint32)<<(8*d)],dtype=tl.uint32,is_pure=True,pack=1)
    tl.store(OUT+e*M*N+r[:,None]*N+c[None,:],out.to(tl.int64),(r[:,None]<M)&(c[None,:]<N))

qs=(251,241,239,233)
def cent(x,p):return ((x+p//2)%p-p//2).to(torch.int8)
def run(m,k,n):
    torch.manual_seed(6347)
    xs=[torch.randint(0,2**32,(m,k),device='cuda',dtype=torch.int64) for _ in range(3)]
    ws=[torch.randint(-2**31,2**31,(k,n),device='cuda',dtype=torch.int32) for _ in range(3)]
    compact=[CompactWeight(w) for w in ws]
    edges=[CompactWeight(w) for w in (ws[0]+ws[1],ws[1]+ws[2],ws[2]-ws[0])]
    # Sample independent uniformly distributed, already owner-encoded residue shares.
    xa=torch.stack([torch.stack([torch.randint(-p//2+1,p//2+1,(m,k),device='cuda',dtype=torch.int8) for p in qs]) for _ in range(3)])
    ya=torch.stack([torch.stack([torch.randint(-p//2+1,p//2+1,(k,n),device='cuda',dtype=torch.int8) for p in qs]) for _ in range(3)])
    ycomb=torch.stack([torch.stack([cent(y,p) for y,p in zip(v,qs)]) for v in (ya[0].int()+ya[1],ya[1].int()+ya[2],ya[2].int()-ya[0])])
    def current():return local_products_tuned(*xs,*compact,32)
    def ring32():return [ring_matmul_tuned(x,y,32) for x,y in zip((xs[0]+xs[1],xs[1]+xs[2],xs[0]-xs[2]),edges)]
    def fused():
        out=torch.empty((3,m,n),device='cuda',dtype=torch.int64)
        _word_edges[(triton.cdiv(m,32),triton.cdiv(n,128),3)](*xs,*(q.words for q in edges),out,m,k,n,32,128,32,num_warps=4,num_stages=1)
        return out
    for a,b in zip(fused(),ring32()):
        assert torch.equal(a,b)
    def prime():
        out=torch.empty((3,4,m,n),device='cuda',dtype=torch.uint8)
        _prime_edges[(triton.cdiv(m,32),triton.cdiv(n,64),12)](xa,ycomb,out,m,k,n,32,64,64,num_warps=4,num_stages=2)
        return out
    z=prime()
    rows=[0,1,3,m-1];cols=[0,1,n-1]
    a=xa[:,:,rows].cpu().int(); w=ya[:,:,:,cols].cpu().int()
    for e,(A,W) in enumerate(zip((a[0]+a[1],a[1]+a[2],a[0]-a[2]),(w[0]+w[1],w[1]+w[2],w[2]-w[0]))):
        for lane,p in enumerate(qs):
            assert torch.equal(z[e,lane,rows][:,cols].cpu().int(),(A[lane]@W[lane])%p)
    graphs=[]
    for f in (current,fused,prime):
        f()
        g=torch.cuda.CUDAGraph()
        with torch.cuda.graph(g):o=f()
        graphs.append(g)
    timings=[[] for _ in graphs]
    for rep in range(9):
        order=[0,1,2] if rep%2==0 else [2,1,0];order=order[rep%3:]+order[:rep%3]
        for i in order:
            g=graphs[i]
            for _ in range(5): g.replay()
            a,b=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
            a.record()
            for _ in range(25): g.replay()
            b.record();b.synchronize()
            timings[i].append(a.elapsed_time(b)/25)
    print(json.dumps(dict(shape=[m,k,n],columns=['existing_fused_ring32','signed_edge_fused_ring32','signed_edge_crt4'],median_ms=[statistics.median(t) for t in timings],raw_ms=timings)),flush=True)
run(8192,512,128)
