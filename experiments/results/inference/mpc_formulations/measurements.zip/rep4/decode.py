from pathlib import Path
import json,os,sys
from threadpoolctl import threadpool_limits
from rep4gpu.gpu.matmul.kernels import CompactWeight
from rep4gpu.models.device_inference import DeviceInferenceParty
from rep4gpu.protocol.runtime import PreparedMatrix
from experiments.benchmarks.inference.device_inference import main
import torch,triton,triton.language as tl

@triton.jit
def _decode(X0,X1,X2,Y01,Y12,OUT,N:tl.constexpr,K:tl.constexpr,BN:tl.constexpr,BK:tl.constexpr):
    c=tl.program_id(0)*BN+tl.arange(0,BN)
    h=tl.arange(0,BK)
    s0=tl.full((BK,BN),0,tl.uint32)
    s1=tl.full((BK,BN),0,tl.uint32)
    s4=tl.full((BK,BN),0,tl.uint32)
    for block in range(tl.cdiv(K,BK)):
        k=block*BK+h
        x0=tl.load(X0+k,k<K,0).to(tl.uint32)[:,None]
        x1=tl.load(X1+k,k<K,0).to(tl.uint32)[:,None]
        x2=tl.load(X2+k,k<K,0).to(tl.uint32)[:,None]
        idx=k[:,None]*N+c[None,:]
        m=(k[:,None]<K)&(c[None,:]<N)
        a=tl.load(Y01+idx,m,0).to(tl.uint32)
        b=tl.load(Y12+idx,m,0).to(tl.uint32)
        s0+=(x0+x1)*a
        s1+=(x1+x2)*b
        s4+=(x0-x2)*(b-a)
    tl.store(OUT+c,tl.sum(s0,0).to(tl.int64),c<N)
    tl.store(OUT+N+c,tl.sum(s1,0).to(tl.int64),c<N)
    tl.store(OUT+2*N+c,tl.sum(s4,0).to(tl.int64),c<N)

def prepare(self,weight,*,storage):
    assert storage=='words32'
    x0,x1,x2=(w.to(torch.int32) for w in weight.parts)
    return PreparedMatrix((CompactWeight(x0+x1),CompactWeight(x1+x2)))
def matmul(self,x,y):
    m,k=x.shape
    n=y.shape[1]
    assert m==1 and self.bits==32 and len(y.parts)==2
    out=torch.empty((3,1,n),dtype=torch.int64,device=x.device)
    _decode[(triton.cdiv(n,32),)](*x.parts,y.parts[0].words,y.parts[1].words,out,n,k,32,32,num_warps=4)
    contributions=[None]*5
    contributions[(self.party-1)%4],contributions[self.party],contributions[4]=out.unbind(0)
    return self._reshare_product(contributions,False,x.device)
if __name__=='__main__':
    candidate=os.environ['EDGE_COMPARE']=='candidate'
    if candidate:
        DeviceInferenceParty.prepare_weight_share=prepare
        DeviceInferenceParty.matmul=matmul
    path=Path(sys.argv[sys.argv.index('--output')+1])
    with threadpool_limits(limits=1,user_api='blas'):main()
    report=json.loads(path.read_text())
    report['variant']='two-word signed-edge fused decode' if candidate else 'baseline'
    if candidate: report['results'][0]['local_matmul_backend']='two-word signed-edge fused decode'
    path.write_text(json.dumps(report,indent=2)+'\n')
