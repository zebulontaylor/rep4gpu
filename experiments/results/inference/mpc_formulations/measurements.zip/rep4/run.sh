#!/bin/sh
set -eu
cd /home/zeb/Desktop/SIV
export PYTHONPATH=/home/zeb/Desktop/SIV
export EDGE_COMPARE="${1:-candidate}"
exec .venv/bin/python /tmp/siv-edge-research-20261118/full.py --batch 128 --width 2048 --bits 32 --binary-bits 32 --fractional-bits 14 --prepared --weight-storage strassen32 --optimized --gpu-open --rounding probabilistic --bounded-sign --phase-graphs --graph-check-at-send --sparse-products --narrow-products --repeats 9 --output "/tmp/siv-edge-research-20261118/full-$EDGE_COMPARE${2:-}.json"
