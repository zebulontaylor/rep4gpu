from random import Random
from itertools import product
K=32; M=2**K
Z=(0,0); I=(1,0); W=(0,1); V=(M-1,M-1)
pts=[I,W,V,None]
def add(x,y):return ((x[0]+y[0])%M,(x[1]+y[1])%M)
def sub(x,y):return ((x[0]-y[0])%M,(x[1]-y[1])%M)
def mul(x,y):
 a,b=x;c,d=y
 return ((a*c-b*d)%M,(a*d+b*c-b*d)%M)
def inv(x):
 a,b=x; n=pow((a*a-a*b+b*b)%M,-1,M)
 return (((a-b)*n)%M,(-b*n)%M)
def sm(A):
 s=Z
 for x in A:s=add(s,x)
 return s
def scale(x,s):return mul(x,(s,0))
def fc(e):return Z if pts[e] is None else sub(Z,inv(pts[e]))
def fe(y,i):
 slope=sm(scale(fc(e),u) for e,u in enumerate(y)); c=sm((u,0) for u in y)
 return slope if pts[i] is None else add(c,mul(pts[i],slope))
def mask(r,t,i):
 c=sm((u,0) for u in r); b=sm(add(scale(fc(e),r[e]),t[e]) for e in range(4)); a=sm(mul(fc(e),t[e]) for e in range(4)); x=pts[i]
 return a if x is None else add(c,mul(x,add(b,mul(x,a))))
def rec(vals,inds):
 # solve at zero via interpolation with infinity represented by the quadratic coefficient
 if 3 in inds:
  i,j=(n for n in inds if n!=3); x=pts[i]; y=pts[j]; a=vals[3]
  fi=sub(vals[i],mul(a,mul(x,x))); fj=sub(vals[j],mul(a,mul(y,y)))
  return mul(sub(mul(y,fi),mul(x,fj)),inv(sub(y,x)))
 out=Z
 for i in inds:
  cn=I
  for j in inds:
   if i!=j:cn=mul(cn,mul(sub(Z,pts[j]),inv(sub(pts[i],pts[j]))))
  out=add(out,mul(vals[i],cn))
 return out
rng=Random(402891); nerrors=0
for it in range(1000):
 x,y,r=([rng.randrange(M) for e in pts] for _ in range(3)); t=[(rng.randrange(M),rng.randrange(M)) for e in pts]
 vals=[add(mul(fe(x,i),fe(y,i)),mask(r,t,i)) for i in range(4)]
 tru=((sum(x)*sum(y)+sum(r))%M,0)
 for i in range(4):
  got=rec(vals,[j for j in range(4) if j!=i]); assert got==tru
  # degree-1 evaluation and degree-2 mask at i ignore i's unknown component and both of its seeds
  x1=x.copy();x1[i]+=9003; assert fe(x1,i)==fe(x,i)
  r1=r.copy();r1[i]+=1; t1=t.copy();t1[i]=add(t1[i],(42,3));assert mask(r1,t1,i)==mask(r,t,i)
  for err in [(1,0),(0,1),(2**31,0),(0,2**31),(2**31,2**31)]:
   bad=vals.copy();bad[i]=add(bad[i],err); assert rec(bad,[0,2,3])!=rec(bad,[1,2,3]);nerrors+=1
print('OK',it+1,'full-width random ring32 products, 4000 omitted-party interpolation triples,',nerrors,'single-coordinate alterations, including nonunits')
def ce(parts,e):
 slope=sm(mul(fc(i),u) for i,u in enumerate(parts)); return slope if pts[e] is None else add(sm(parts),mul(pts[e],slope))
def maske(r,t,i):
 c=sm(r);b=sm(add(mul(fc(e),r[e]),t[e]) for e in range(4));a=sm(mul(fc(e),t[e]) for e in range(4));x=pts[i]
 return a if x is None else add(c,mul(x,add(b,mul(x,a))))
for batch,k,n in [(1,9,18),(8,17,12),(3,7,10)]:
 xs=[[[rng.randrange(M) for e in range(4)] for j in range(k)] for i in range(batch)]; ws=[[[rng.randrange(M) for e in range(4)] for j in range(n)] for i in range(k)]
 for i in range(batch):
  for j in range(n//2):
   r,t=([(rng.randrange(M),rng.randrange(M)) for e in range(4)] for h in range(2));v=[]
   for e in range(4):
    aa=[fe(xs[i][k1],e) for k1 in range(k)]; bb=[ce(list(zip(ws[k1][2*j],ws[k1][2*j+1])),e) for k1 in range(k)]; ac=sum(a*c for (a,b),(c,d) in zip(aa,bb));bd=sum(b*d for (a,b),(c,d) in zip(aa,bb));dd=sum((a+b)*(c+d) for (a,b),(c,d) in zip(aa,bb));v.append(add((ac-bd,dd-ac-2*bd),maske(r,t,e)))
   z=sub(rec(v,[0,2,3]),sm(r)); true=tuple(sum(sum(xs[i][kk])*sum(ws[kk][2*j+d]) for kk in range(k))%M for d in [0,1]);assert z==true and rec(v,[0,2,3])==rec(v,[1,2,3])
print('OK 144 packed full-width ring32 output elements across matrix shapes 1x9x18, 8x17x12, 3x7x10, with masks and 3 half-width ordered base GEMMs.')
