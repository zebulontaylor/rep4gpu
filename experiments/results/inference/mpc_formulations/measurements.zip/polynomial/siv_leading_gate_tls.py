"""Four real loopback TLS processes exercising a candidate Rep4 GEMM gate.

Run with the SIV virtual environment and the repository root on PYTHONPATH.
The two-round broadcast echoes full messages for a simple correctness reference.
"""

import collections
import concurrent.futures
import hashlib
import json
import math
import multiprocessing
import secrets
import ssl
import sys
import tempfile

import numpy as np
import torch
from experiments.benchmarks.inference.socket_inference import (
    MeteredTransport,
    certificates,
    reserve_addresses,
)
from rep4gpu.models.inference import InferenceParty
from rep4gpu.protocol.prg import random_bytes
from rep4gpu.protocol.setup import correlated_seeds
from rep4gpu.protocol.runtime import Share


def accept_frame(data, size, width, modulus):
    if data is None or len(data) != size * width:
        return None
    if any(
        int.from_bytes(data[i : i + width], "little") >= modulus
        for i in range(0, len(data), width)
    ):
        return None
    return data


def reliable_broadcast(party, payload, count, width, modulus, fault):
    """Lamport's OM(1), four simultaneous senders, full-value echoes.

    Honest recipients take the majority of three recipients' observations of each
    sender's message. A missing majority selects the same invalid marker at all
    honest recipients. An honest sender uses its own value.
    """
    role, transport = party.party, party.transport
    nbytes = count * width
    outgoing = {j: payload for j in range(4) if j != role}
    if fault in ("consistent_error", "equivocation", "three_values") and role == 1:
        for j in outgoing:
            delta = (
                1
                if fault == "consistent_error"
                else int(j == 2)
                if fault == "equivocation"
                else j
            )
            x = (int.from_bytes(payload[:width], "little") + delta) % modulus
            outgoing[j] = x.to_bytes(width, "little") + payload[width:]
    received = transport.exchange(outgoing)
    observed = {
        s: accept_frame(received.get(s), count, width, modulus)
        for s in range(4)
        if s != role
    }
    observed[role] = payload

    def record(value):
        return b"\x00" + bytes(nbytes) if value is None else b"\x01" + value

    echoes = {}
    for j in outgoing:
        witnesses = sorted(set(range(4)) - {role, j})
        echoes[j] = b"".join(record(observed[s]) for s in witnesses)
    if fault == "bad_echo" and role == 1:
        echoes[2] = b"bad echoes"
    relayed = transport.exchange(echoes)
    agreed = {role: payload}
    for s in range(4):
        if s == role:
            continue
        votes = [observed[s]]
        for peer in sorted(set(range(4)) - {role, s}):
            envelope = relayed.get(peer, b"")
            witnesses = sorted(set(range(4)) - {role, peer})
            start = witnesses.index(s) * (nbytes + 1)
            block = envelope[start : start + nbytes + 1]
            valid = len(envelope) == 2 * (nbytes + 1) and block[:1] == b"\x01"
            votes.append(
                accept_frame(block[1:], count, width, modulus) if valid else None
            )
        value, multiplicity = collections.Counter(votes).most_common(1)[0]
        agreed[s] = value if multiplicity >= 2 else None
    return agreed


def encode(party, share, ring, wide):
    total = np.zeros(tuple(share.shape), dtype=object)
    for slot, tensor in enumerate(share.parts):
        e = (party.party + slot + 1) % 4
        total += (party.party - e) * (tensor.numpy().astype(object) % ring)
    return total % wide


def fresh_mask(party, e, shape, wide):
    # One shared session counter is burned before this independent key is used.
    # A full 128-bit PRG sample per output also covers the 65-bit reference.
    nonce = party._reserve_nonces((e,))[0]
    key = hashlib.sha256(b"SIV-leading-gate-reference-v1" + party.seeds[e]).digest()
    count = math.prod(shape)
    data = random_bytes(key, nonce, count * 2, ring_bits=64, backend="aes")
    return np.array(
        [
            int.from_bytes(data[i : i + 16], "little") % wide
            for i in range(0, len(data), 16)
        ],
        dtype=object,
    ).reshape(shape)


def masked_product(party, x, w):
    """Return Y(i) and this party's three shares of the output mask."""
    ring = 1 << party.bits
    wide = 2 * ring
    shape = (x.shape[0], w.shape[1])
    role = party.party
    y = encode(party, x, ring, wide) @ encode(party, w, ring, wide)
    parts = []
    for slot in range(3):
        excluded = (role + slot + 1) % 4
        r = fresh_mask(party, excluded, shape, wide)
        t = fresh_mask(party, excluded, shape, wide)
        y += (role - excluded) * (r + role * t)
        parts.append((-t) % ring)
    return y % wide, parts


def output_share(party, parts, correction, excluded):
    ring = 1 << party.bits
    for slot, part in enumerate(parts):
        if (party.party + slot + 1) % 4 == excluded:
            part = (part + correction) % ring
        if party.bits == 64:
            part = (part + 2**63) % ring - 2**63
        parts[slot] = torch.from_numpy(part.astype(np.int64))
    return Share(tuple(parts))


def leading_gate(party, x, w, fault=None):
    y, parts = masked_product(party, x, w)
    shape = y.shape
    wide = 1 << (party.bits + 1)
    width = (party.bits + 8) // 8
    payload = b"".join(int(v % wide).to_bytes(width, "little") for v in y.flat)
    agreed = reliable_broadcast(party, payload, math.prod(shape), width, wide, fault)
    if any(v is None for v in agreed.values()):
        raise ValueError("reliable broadcast returned an invalid value")
    words = [
        np.array(
            [
                int.from_bytes(agreed[s][i : i + width], "little")
                for i in range(0, len(payload), width)
            ],
            dtype=object,
        ).reshape(shape)
        for s in range(4)
    ]
    y0, y1, y2, y3 = words
    left = (y0 - 2 * y1 + y2) % wide
    right = (y1 - 2 * y2 + y3) % wide
    if np.any(left % 2) or not np.array_equal(left, right):
        raise ValueError("degree-two evaluation check failed")
    return output_share(party, parts, left // 2, excluded=0)


def worker(
    role,
    addresses,
    ca,
    identity,
    context,
    xclear,
    wclear,
    dims,
    bits,
    fault,
    gate=leading_gate,
):
    torch.set_num_threads(1)
    server = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    server.verify_mode = ssl.CERT_REQUIRED
    server.load_cert_chain(identity["certificate"], identity["key"])
    server.load_verify_locations(ca)
    client = ssl.create_default_context(ssl.Purpose.SERVER_AUTH, cafile=ca)
    client.load_cert_chain(identity["certificate"], identity["key"])
    transport = MeteredTransport(
        role,
        [tuple(a) for a in addresses],
        timeout=8,
        server_context=server,
        client_context=client,
        peer_hostnames={i: f"party{i}" for i in range(4)},
    )
    try:
        seeds = correlated_seeds(role, transport, context=context)
        party = InferenceParty(
            role,
            transport,
            seeds,
            device="cpu",
            bits=bits,
            binary_bits=32 if bits == 32 else 64,
            prg="aes",
        )
        xshape, wshape = dims
        x = party.input(
            0, torch.tensor(xclear, dtype=torch.int64) if role == 0 else None, xshape
        )
        w = party.input(
            1, torch.tensor(wclear, dtype=torch.int64) if role == 1 else None, wshape
        )
        before = transport.bytes_sent, transport.rounds
        try:
            out = gate(party, x, w, fault)
        except ValueError as error:
            return dict(role=role, accepted=False, reason=str(error))
        # For injected faults, only the test driver inspects the returned shares.
        # It reconstructs from honest parties after checking all their decisions.
        if fault:
            return dict(role=role, accepted=True, parts=[p.tolist() for p in out.parts])
        gate_bytes = transport.bytes_sent - before[0]
        gate_rounds = transport.rounds - before[1]
        raw = party.open(out)
        # Exercise a fresh invocation on the same resident model. Its shares feed
        # the repository's exact floor/ReLU path directly, with no re-encoding.
        second = gate(party, x, w)
        final = party.open(party.trunc_relu(second, 14))
        return dict(
            role=role,
            accepted=True,
            raw=raw.tolist(),
            final=final.tolist(),
            distinct_shares=any(
                not torch.equal(a, b) for a, b in zip(out.parts, second.parts)
            ),
            gate_bytes=gate_bytes,
            gate_rounds=gate_rounds,
        )
    finally:
        transport.close()


def main():
    rng = np.random.default_rng(96381)
    with tempfile.TemporaryDirectory(prefix="siv-leading-gate-") as directory:
        ca, identities = certificates(directory)
        result = []
        with concurrent.futures.ProcessPoolExecutor(
            4, mp_context=multiprocessing.get_context("spawn")
        ) as pool:
            for bits, fault in [
                (16, None),
                (32, None),
                (64, None),
                (32, "consistent_error"),
                (32, "equivocation"),
                (32, "three_values"),
                (32, "bad_echo"),
            ]:
                # Values include arbitrary ring patterns, not only bounded Q14.
                x = rng.integers(-(1 << 63), (1 << 63) - 1, size=(3, 9), dtype=np.int64)
                w = rng.integers(-(1 << 63), (1 << 63) - 1, size=(9, 7), dtype=np.int64)
                want = x.astype(object) @ w.astype(object)
                ring = 1 << bits
                want %= ring
                signed = (want + ring // 2) % ring - ring // 2
                activation = np.maximum(signed // 2**14, 0)
                want = signed
                addresses = reserve_addresses()
                context = secrets.token_bytes(32)
                fs = [
                    pool.submit(
                        worker,
                        i,
                        addresses,
                        ca,
                        identities[i],
                        context,
                        x.tolist() if i == 0 else None,
                        w.tolist() if i == 1 else None,
                        (x.shape, w.shape),
                        bits,
                        fault,
                    )
                    for i in range(4)
                ]
                rows = [f.result(timeout=40) for f in fs]
                honest = [r for r in rows if not fault or r["role"] != 1]
                if fault in ("consistent_error", "three_values"):
                    assert all(not r["accepted"] for r in honest), rows
                elif fault:
                    assert all(r["accepted"] for r in honest), rows
                    # Harness-only independent crosscheck of honest outputs. Do not
                    # give these shares or the reference value to any worker.
                    recovered = []
                    for e in range(4):
                        copies = [
                            np.array(r["parts"][(e - r["role"] - 1) % 4], dtype=object)
                            for r in honest
                            if r["role"] != e
                        ]
                        assert all(np.array_equal(copies[0], c) for c in copies)
                        recovered.append(copies[0])
                    assert np.array_equal(sum(recovered) % ring, want % ring)
                else:
                    assert all(
                        r["accepted"]
                        and r["distinct_shares"]
                        and r["raw"] == want.tolist()
                        and r["final"] == activation.tolist()
                        for r in rows
                    ), rows
                summary = dict(
                    bits=bits,
                    fault=fault or "none",
                    honest_roles=len(honest),
                    all_honest_accepted=all(r["accepted"] for r in honest),
                )
                if not fault:
                    summary.update(
                        gate_payload_bytes=sum(r["gate_bytes"] for r in rows),
                        gate_rounds=rows[0]["gate_rounds"],
                        checked_floor_relu=True,
                    )
                result.append(summary)
                print(json.dumps(summary), file=sys.stderr, flush=True)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
