"""Exhaustive interior equivocation check for the half/low k-bit wire proposal."""

from itertools import product

for bits in (1, 2, 3):
    R = 1 << bits
    S = 2 * R
    trials = 0
    accepted = 0
    honest = 0
    for co in product(range(S), repeat=3):
        y = [sum(u * (i**j) for j, u in enumerate(co)) % S for i in range(4)]
        natural = (y[1] % R, y[1] // 2, y[2] // 2, y[2] % R)
        for seat in (1, 2):
            for first, second in product(range(R), repeat=2):
                lo1, hi1, hi2, lo2 = natural
                if seat == 1:
                    lo1, hi1 = first, second
                else:
                    hi2, lo2 = first, second
                a2 = 2 * hi2 + (y[0] & 1)
                b1 = 2 * hi1 + (y[3] & 1)
                cA = ((y[0] + 1) // 2 + hi2 - lo1) % R
                cB = (hi1 + (y[3] + 1) // 2 - lo2) % R
                passes = a2 % R == lo2 and b1 % R == lo1 and cA == cB
                unchanged = (lo1, hi1, hi2, lo2) == natural
                assert (not passes or cA == co[2] % R) and passes == unchanged
                trials += 1
                accepted += passes
                honest += unchanged
    print("k", bits, "tests", trials, "accepted", accepted, "honest", honest)
