"""Exercise two collector GEMMs around SIV's native private activation, opening only final cascade results."""

import concurrent.futures
import json
import multiprocessing
import secrets
import tempfile

import numpy as np
import siv_leading_collectors as collector
import siv_leading_gate_tls as reference


def worker(role, addresses, ca, identity, context, x, w, dims, bits):
    def gate(party, x_share, w_share, fault=None):
        def product(left, right):
            y, parts = reference.masked_product(party, left, right)
            correction = collector.collect(party, y, party.bits, context, None)
            return reference.output_share(party, parts, correction, excluded=1)

        up = product(x_share, w_share)
        hidden = party.trunc_relu(up, 14)
        transposed = reference.Share(tuple(z.T.contiguous() for z in w_share.parts))
        return party.trunc(product(hidden, transposed), 14)

    return reference.worker(
        role, addresses, ca, identity, context, x, w, dims, bits, None, gate=gate
    )


def main():
    rng = np.random.default_rng(5287)

    def signed(matrix, ring):
        return (matrix + ring // 2) % ring - ring // 2

    results = []
    with tempfile.TemporaryDirectory(prefix="siv-collector-cascade-") as directory:
        ca, identities = reference.certificates(directory)
        with concurrent.futures.ProcessPoolExecutor(
            4, mp_context=multiprocessing.get_context("spawn")
        ) as pool:
            for bits in (16, 32, 64):
                x = rng.integers(
                    -(1 << 63), (1 << 63) - 1, size=(4, 11), dtype=np.int64
                ).astype(object)
                w = rng.integers(
                    -(1 << 63), (1 << 63) - 1, size=(11, 7), dtype=np.int64
                ).astype(object)
                ring = 1 << bits
                hidden = np.maximum(signed(x @ w, ring) // 2**14, 0)
                want = signed(hidden @ w.T, ring) // 2**14
                addresses = reference.reserve_addresses()
                context = secrets.token_bytes(32)
                futures = [
                    pool.submit(
                        worker,
                        i,
                        addresses,
                        ca,
                        identities[i],
                        context,
                        x.tolist() if i == 0 else None,
                        w.tolist() if i == 1 else None,
                        (x.shape, w.shape),
                        bits,
                    )
                    for i in range(4)
                ]
                rows = [f.result(timeout=40) for f in futures]
                assert all(
                    row["raw"] == want.tolist() and row["distinct_shares"]
                    for row in rows
                )
                results.append(
                    dict(
                        bits=bits,
                        input_shape=list(x.shape),
                        weight_shape=list(w.shape),
                        tied_down_projection=True,
                        private_floor_relu=True,
                        matched_all_44_outputs_at_all_roles=True,
                        rounds_before_first_open=rows[0]["gate_rounds"],
                        application_payload_before_first_open=sum(
                            r["gate_bytes"] for r in rows
                        ),
                    )
                )
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
