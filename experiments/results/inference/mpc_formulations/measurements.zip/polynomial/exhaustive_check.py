"""Algebra checks for the leading-coefficient four-point ring GEMM bridge. CPU only."""
from itertools import product
from random import Random
import json


def evaluate(poly, node, modulus):
    return sum(coefficient * node**power for power, coefficient in enumerate(poly)) % modulus


def psi(poly, modulus):
    a, b, c = poly
    return c % modulus


def psi_from_evaluations(values, bits):
    y0, y1, y2, y3 = values
    modulus = 1 << (bits+1)
    numerators = ((y0-2*y1+y2) % modulus, (y1-2*y2+y3) % modulus)
    return tuple(None if n % 2 else n//2 for n in numerators)


def embedded_eval(components, node, modulus):
    return sum((node-j)*components[j] for j in range(4))%modulus


def full_checks():
    totals = {'quadratics_exhaustive': 0, 'single_coordinate_errors': 0, 'mask_kernels_checked': 0, 'affine_product_pairs_exhaustive': 0, 'matrix_outputs_random':0, 'fresh_mask_exclusion':0}
    for bits in (1,2,3):
        mod = 1 << (bits+1)
        for poly in product(range(mod),repeat=3):
            y = [evaluate(poly,node,mod) for node in range(4)]
            c0,c1 = psi_from_evaluations(y,bits)
            assert c0 == c1 == psi(poly,mod//2)
            totals['quadratics_exhaustive']+=1
            for i in range(4):
                for err in range(1,mod):
                    z = y.copy(); z[i]=(z[i]+err)%mod
                    c0,c1 = psi_from_evaluations(z,bits)
                    assert c0 is None or c1 is None or c0!=c1
                    totals['single_coordinate_errors']+=1
        for i in range(4):
            kernel = {poly for poly in product(range(mod),repeat=3) if evaluate(poly,i,mod)==0}
            masks = {((-i*r)%mod,(r-i*t)%mod,t%mod) for r,t in product(range(mod),repeat=2)}
            assert masks==kernel and len(masks)==mod**2
            counts = [0]*(mod//2)
            for poly in masks: counts[psi(poly,mod//2)]+=1
            assert len(set(counts))==1
            totals['mask_kernels_checked']+=1
        for a,b,c,d in product(range(mod),repeat=4):
            p=(a*c,a*d+b*c,b*d)
            assert psi(p,mod//2)==(b*d)%(mod//2)
            totals['affine_product_pairs_exhaustive']+=1
    rng=Random(996432)
    for bits in (1,2,3,4,7,8,16,32,64):
        mod=1<<(bits+1); base=mod//2
        for rows,depth,cols in ((1,3,7),(3,7,5),(4,17,6)):
            xs=[[[rng.randrange(base) for i in range(4)] for j in range(depth)] for m in range(rows)]
            ws=[[[rng.randrange(base) for i in range(4)] for n in range(cols)] for j in range(depth)]
            for m,n in product(range(rows),range(cols)):
                rt=[(rng.randrange(mod),rng.randrange(mod)) for i in range(4)]; vals=[]
                for i in range(4):
                    masked=sum((i-j)*(r+i*t) for j,(r,t) in enumerate(rt))
                    alternate=rt.copy(); alternate[i]=(rng.randrange(mod),rng.randrange(mod))
                    assert masked%mod==sum((i-j)*(r+i*t) for j,(r,t) in enumerate(alternate))%mod
                    h=0
                    for j in range(depth):
                        u=embedded_eval(xs[m][j],i,mod);v=embedded_eval(ws[j][n],i,mod)
                        q=xs[m][j].copy(); q[i]=rng.randrange(base);assert u==embedded_eval(q,i,mod)
                        h+=u*v
                    vals.append((h+masked)%mod)
                    totals['fresh_mask_exclusion']+=1
                opened=[z for z in psi_from_evaluations(vals,bits)]
                assert opened[0]==opened[1] and opened[0] is not None
                pieces=[-t%base for i,(r,t) in enumerate(rt)];pieces[0]+=opened[0]
                want=sum(sum(xs[m][j])*sum(ws[j][n]) for j in range(depth))%base
                assert sum(pieces)%base==want
                totals['matrix_outputs_random']+=1
    return totals

if __name__=='__main__': print(json.dumps(full_checks(),indent=2))
