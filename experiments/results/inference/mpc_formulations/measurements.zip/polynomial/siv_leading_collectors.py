"""Experimental checked collector protocol using five base-ring message vectors.

Run with the same environment as siv_leading_gate_tls.py, stored beside this file.
The two data exchanges are followed by an OM(1) broadcast of local check results
before callers receive shares. The agreement is a reference protocol, not a
latency optimization. This code is for experiments with synthetic inputs.
"""

import concurrent.futures
import hashlib
import json
import math
import multiprocessing
import secrets
import tempfile
import sys

import numpy as np
import siv_leading_gate_tls as reference


def digest(label, data):
    return hashlib.sha256(label + data).digest()


def pack(values, bits):
    return b"".join(int(x).to_bytes(bits // 8, "little") for x in values.flat)


def unpack(data, shape, bits):
    width = bits // 8
    return np.array(
        [
            int.from_bytes(data[i : i + width], "little")
            for i in range(0, len(data), width)
        ],
        dtype=object,
    ).reshape(shape)


def collect(party, values, bits, context, fault):
    role = party.party
    ring = 1 << bits
    shape = values.shape
    nbytes = math.prod(shape) * (bits // 8)
    epoch = getattr(party, "_collector_epoch", 0)
    party._collector_epoch = epoch + 1
    label = (
        b"SIV-leading-collector-v1"
        + context
        + epoch.to_bytes(8, "little")
        + bytes([bits])
        + b"".join(int(n).to_bytes(8, "little") for n in shape)
    )
    if (fault == "changed_role1" and role == 1) or (
        fault == "changed_role2" and role == 2
    ):
        values = values.copy()
        values.flat[0] = (values.flat[0] + 2) % (2 * ring)
    if role == 1:
        outgoing = {0: pack(values % ring, bits), 3: pack(values // 2, bits)}
        if fault == "equivocating_role1":
            outgoing[0] = bytes([outgoing[0][0] ^ 1]) + outgoing[0][1:]
        elif fault == "malformed_role1":
            outgoing[0] = b""
    elif role == 2:
        outgoing = {0: pack(values // 2, bits), 3: pack(values % ring, bits)}
    else:
        outgoing = {}
    incoming = party.transport.exchange(outgoing)
    valid = True
    correction = None
    outgoing = {}
    if role in (0, 3):
        expect = {1, 2}
        valid = set(incoming) == expect and all(
            len(incoming[s]) == nbytes for s in expect
        )
        a, b = (
            unpack(incoming[s], shape, bits) if valid else np.zeros(shape, dtype=object)
            for s in (1, 2)
        )
        if role == 0:
            low1 = a
            low2 = (2 * b + values % 2) % ring
            correction = ((values + 1) // 2 - low1 + b) % ring
        else:
            low1 = (2 * a + values % 2) % ring
            low2 = b
            correction = (a - low2 + (values + 1) // 2) % ring
        raw = pack(correction, bits)
        tag = digest(label + b"collector", pack(low1, bits) + pack(low2, bits) + raw)
        outgoing[3 - role] = tag
        outgoing[2] = raw if role == 0 else digest(label + b"output", raw)
        if fault == "wrong_delivery" and role == 0:
            outgoing[2] = bytes([raw[0] ^ 1]) + raw[1:]
        elif fault == "wrong_check" and role == 3:
            outgoing[0] = bytes(32)
        elif fault == "wrong_output_hash" and role == 3:
            outgoing[2] = bytes(32)
    accepted = party.transport.exchange(outgoing)
    if role in (0, 3):
        valid = valid and set(accepted) == {3 - role} and accepted[3 - role] == tag
    elif role == 2:
        valid = (
            set(accepted) == {0, 3}
            and len(accepted[0]) == nbytes
            and digest(label + b"output", accepted[0]) == accepted[3]
        )
        if valid:
            correction = unpack(accepted[0], shape, bits)
    else:
        valid = not accepted
    status = bytes([int(valid)])
    # A malicious party can always force an abort. Broadcasting the status
    # prevents disagreement about the verdict among the three honest roles.
    flag_fault = {
        "status_equivocation": "equivocation",
        "status_rejection": "consistent_error",
    }.get(fault)
    status_views = reference.reliable_broadcast(party, status, 1, 1, 2, flag_fault)
    if valid is False or any(v != b"\x01" for v in status_views.values()):
        raise ValueError("collector transcript rejected")
    return correction


def worker(role, addresses, ca, identity, context, x, w, dims, bits, fault):
    def gate(party, x, w, fault=None):
        y, parts = reference.masked_product(party, x, w)
        c = collect(party, y, party.bits, context, fault)
        return reference.output_share(party, parts, c, excluded=1)

    return reference.worker(
        role, addresses, ca, identity, context, x, w, dims, bits, fault, gate=gate
    )


def main():
    faults = {
        None: None,
        "changed_role1": 1,
        "changed_role2": 2,
        "equivocating_role1": 1,
        "malformed_role1": 1,
        "wrong_delivery": 0,
        "wrong_check": 3,
        "wrong_output_hash": 3,
        "status_equivocation": 1,
        "status_rejection": 1,
    }
    rng = np.random.default_rng(97331)
    with tempfile.TemporaryDirectory(prefix="siv-collector-") as directory:
        ca, identities = reference.certificates(directory)
        results = []
        with concurrent.futures.ProcessPoolExecutor(
            4, mp_context=multiprocessing.get_context("spawn")
        ) as pool:
            for bits, fault in [(16, None), (32, None), (64, None)] + [
                (32, f) for f in faults if f
            ]:
                x = rng.integers(-(1 << 63), (1 << 63) - 1, size=(3, 9), dtype=np.int64)
                w = rng.integers(-(1 << 63), (1 << 63) - 1, size=(9, 7), dtype=np.int64)
                ring = 1 << bits
                want = (
                    x.astype(object) @ w.astype(object) + ring // 2
                ) % ring - ring // 2
                addresses = reference.reserve_addresses()
                context = secrets.token_bytes(32)
                futures = [
                    pool.submit(
                        worker,
                        i,
                        addresses,
                        ca,
                        identities[i],
                        context,
                        x.tolist() if i == 0 else None,
                        w.tolist() if i == 1 else None,
                        (x.shape, w.shape),
                        bits,
                        fault,
                    )
                    for i in range(4)
                ]
                rows = [f.result(timeout=40) for f in futures]
                honest = [r for r in rows if r["role"] != faults[fault]]
                expected = fault in (None, "status_equivocation")
                assert all(r["accepted"] == expected for r in honest), rows
                case = dict(
                    bits=bits,
                    fault=fault or "none",
                    honest_roles=len(honest),
                    all_honest_accepted=expected,
                )
                if fault is None:
                    assert all(
                        r["raw"] == want.tolist()
                        and r["final"] == np.maximum(want // 2**14, 0).tolist()
                        and r["distinct_shares"]
                        for r in rows
                    )
                    total = sum(r["gate_bytes"] for r in rows)
                    body = 5 * 21 * bits // 8
                    assert total == body + 96 + 60 and all(
                        r["gate_rounds"] == 4 for r in rows
                    )
                    case.update(
                        gate_payload_bytes=total,
                        data_vectors_bytes=body,
                        hash_bytes=96,
                        status_agreement_bytes=60,
                        rounds=4,
                        checked_floor_relu=True,
                    )
                elif expected:
                    pieces = []
                    for e in range(4):
                        copies = [
                            np.array(r["parts"][(e - r["role"] - 1) % 4], dtype=object)
                            for r in honest
                            if r["role"] != e
                        ]
                        assert all(np.array_equal(copies[0], c) for c in copies)
                        pieces.append(copies[0])
                    assert np.array_equal(sum(pieces) % ring, want % ring)
                results.append(case)
                print(json.dumps(case), file=sys.stderr, flush=True)
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
