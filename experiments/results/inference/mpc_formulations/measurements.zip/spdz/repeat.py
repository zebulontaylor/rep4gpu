import re, json, shutil, subprocess, sys, tempfile, time
from pathlib import Path
fixture=Path('/home/zeb/Desktop/SIV/tests/fixtures/mpspdz/toy_ffn64')
mp=Path('/home/zeb/Desktop/mp-spdz-toy/MP-SPDZ')
out=Path('/tmp/siv-research-3pc')
program='siv_research'
expected=json.loads((fixture/'fixture.json').read_text())['expected_logits']
configs=[('rep4-ring',4,4),('ps-rep-ring',3,3),('sy-rep-ring',3,3)]
schedule=[configs[(j+i)%3] for i in range(6) for j in range(3)]+[('malicious-rep-ring',3,0)]
for i,(name,n,split) in enumerate(schedule):
    out=Path('/tmp/siv-research-3pc/rounds')/str(i)
    out.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        d=Path(tmp)
        pd=d/'Player-Data'
        pd.mkdir()
        for cert in (mp/'Player-Data').iterdir():
            if cert.suffix in ('.pem','.key','.0'):
                shutil.copy(cert,pd/cert.name)
        for p in range(n):
            shutil.copy(fixture/f'Input-P{p}-0.txt',pd/f'Input-P{p}-0')
        source=d/'Programs/Source'
        source.mkdir(parents=True)
        shutil.copy(fixture/'reference.mpc',source/(program+'.mpc'))
        r=subprocess.run([sys.executable,str(mp/'compile.py'),'-R','64',*(['-Z',str(split)] if split else ['-Y']),program],cwd=d,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        (out/f'{name}_compile.log').write_text(r.stdout)
        if r.returncode:
            print(name, 'compile',r.returncode,r.stdout[-650:],flush=True)
            continue
        logs=[open(out/f'{name}_{p}.log','w') for p in range(n)]
        exe=mp/'bin/Linux-adx'/(name+'-party.x')
        ps=[subprocess.Popen([exe,str(p),program,'-R','64','-v','-pn',str(30761+4*i)],cwd=d,stdout=logs[p],stderr=subprocess.STDOUT) for p in range(n)]
        start=time.monotonic()
        try:
            for p in ps:p.wait(timeout=max(.1,90-(time.monotonic()-start)))
        except subprocess.TimeoutExpired:pass
        finally:
            for p in ps:
                if p.poll() is None:p.kill()
                p.wait()
            for log in logs:log.close()
        t=(out/f'{name}_0.log').read_text()
        rec=re.findall(r'(?m)^LOGIT (\d+) (\d+) (-?\d+)$',t)
        valid=len(rec)==len(expected)*len(expected[0]) and all(int(v)==expected[int(row)][int(col)] for row,col,v in rec)
        print(name,[p.returncode for p in ps],len(rec),valid, 'results', re.findall(r'(?m)^(?:Time = |Global data sent = ).+$',t), t[-400:] if not valid else '', flush=True)
