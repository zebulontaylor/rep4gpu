import hashlib,json,re,shutil,subprocess,sys,tempfile,time
from pathlib import Path
import numpy as np
mp=Path('/home/zeb/Desktop/mp-spdz-toy/MP-SPDZ')
out=Path('/tmp/siv-research-3pc/compare-affine-q14')
out.mkdir(exist_ok=True)
observations=[]
for case,(m,k,n) in enumerate([(8,16,8)]):
    for t in range(4):
        mode=['direct','project','project','direct'][t]
        dst=out/f'{m}x{k}x{n}-{t}-{mode}'
        dst.mkdir(exist_ok=True)
        head=f"""from Compiler.library import check_point,print_ln,start_timer,stop_timer
from Compiler.types import sint
m,k,n={m},{k},{n}
reps=4
X=sint.Matrix(m,k)
WT=sint.Matrix(n,k)
bias=sint.Array(n)
Y=sint.Matrix(m,n)
X.input_from(0)
WT.input_from(1)
bias.input_from(1)
"""
        if mode=='project':
            head+="Z=sint.Matrix(m,n)\nZ.input_from(2)\n"
        head+="Y.input_from(2)\ncheck_point()\nstart_timer(1)\nchecks=[]\n"
        if mode=='project':
            body="""challenge=sint.get_random(size=reps*(m+n)).reveal()
check_point()
for t in range(reps):
    u=[challenge[t*(m+n)+i] for i in range(m)]
    r=[challenge[t*(m+n)+m+j] for j in range(n)]
    left=[sum(u[i]*X[i][p] for i in range(m)) for p in range(k)]
    right=[sum(WT[j][p]*r[j] for j in range(n)) for p in range(k)]
    claimed=sum(u[i]*r[j]*Z[i][j] for i in range(m) for j in range(n))
    checks.append((sint.dot_product(left,right)-claimed).equal(0,bit_length=64))
product=Z.get_vector()
"""
        else:body="product=X.direct_mul_trans(WT)\n"
        tail="""for i in range(m):
    for j in range(n):
        low=(product[i*n+j]+(bias[j]<<14)).bit_decompose(32)
        result=(1-low[31])*sint.bit_compose(low[14:31])
        checks.append((result-Y[i][j]).equal(0,bit_length=64))
while len(checks)>1:
    next_checks=[checks[i]*checks[i+1] for i in range(0,len(checks)-1,2)]
    if len(checks)%2:
        next_checks.append(checks[-1])
    checks=next_checks
verdict=checks[0].reveal()
check_point()
stop_timer(1)
print_ln('ACCEPT %s', verdict)
"""
        source=head+body+tail
        (dst/'reference.mpc').write_text(source)
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp)
            pd=d/'Player-Data'
            pd.mkdir()
            src=d/'Programs/Source'
            src.mkdir(parents=True)
            for c in (mp/'Player-Data').iterdir():
                if c.suffix in ('.pem','.key','.0'):shutil.copy(c,pd/c.name)
            (src/'siv_compare.mpc').write_text(source)
            rng=np.random.default_rng(994)
            x=rng.integers(0,2**32,(m,k),dtype=np.uint64)
            wt=rng.integers(0,2**32,(n,k),dtype=np.uint64)
            z=x@wt.T
            bias=rng.integers(-64,65,n,dtype=np.int64)
            low=(z+(bias.astype(np.uint64)<<14)).astype(np.uint32).view(np.int32).astype(np.int64)
            y=np.maximum(0,low//2**14)
            arrs=[x.view(np.int64).reshape(-1),np.concatenate((wt.view(np.int64).reshape(-1),bias)),np.concatenate((z.view(np.int64).reshape(-1),y.reshape(-1))) if mode=='project' else y.reshape(-1)]
            for p,arr in enumerate(arrs):np.savetxt(pd/f'Input-P{p}-0',arr,fmt='%d')
            (pd/'Input-P3-0').write_text('')
            rc=subprocess.run([sys.executable,str(mp/'compile.py'),'-R','64','siv_compare'],cwd=d,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            (dst/'compile.log').write_text(rc.stdout)
            if rc.returncode: print(rc.stdout[-2000:],flush=True);sys.exit(1)
            logs=[open(dst/f'p{p}.log','w') for p in range(4)]
            ps=[subprocess.Popen([str(mp/'spdz2k-party.x'),str(p),'siv_compare','-N','4','-R','64','-e','-v','-pn',str(21480+case*24+t*4),'-b','256'],cwd=d,stdout=logs[p],stderr=subprocess.STDOUT) for p in range(4)]
            start=time.monotonic()
            try:
                for proc in ps:proc.wait(timeout=max(.01,100-(time.monotonic()-start)))
            except subprocess.TimeoutExpired:pass
            finally:
                for proc in ps:
                    if proc.poll() is None:proc.kill()
                    proc.wait()
                for f in logs:f.close()
            codes=[p.returncode for p in ps]
            s=(dst/'p0.log').read_text()
            if any(codes) or 'ACCEPT 1' not in s:
                print(s[-1800:],flush=True)
                sys.exit(1)
            time1=re.search(r'(?m)^Time1 = (\S+) seconds \((\S+) MB, (\d+) rounds',s)
            obs=dict(shape=[m,k,n],mode=mode,trial=t,codes=codes,valid=True,total_seconds=float(re.search(r'(?m)^Time = (\S+) seconds',s)[1]),global_MB=float(re.search(r'(?m)^Global data sent = (\S+) MB',s)[1]),checked_interval_seconds=float(time1[1]),interval_party0_MB=float(time1[2]),interval_party0_rounds=int(time1[3]))
            print(obs,flush=True)
            observations.append(obs)
            (out/'observations.json').write_text(json.dumps(observations,indent=2)+'\n')
