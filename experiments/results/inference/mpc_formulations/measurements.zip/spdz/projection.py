from pathlib import Path
import hashlib,json,shutil,subprocess,sys,tempfile,time
mp=Path('/home/zeb/Desktop/mp-spdz-toy/MP-SPDZ')
droot=Path('/tmp/siv-research-3pc/projection')
droot.mkdir(exist_ok=True)
source="""from Compiler.library import check_point,print_ln
from Compiler.types import sint
m,k,n=2,3,2
reps=4
X=sint.Matrix(m,k)
W=sint.Matrix(k,n)
Z=sint.Matrix(m,n)
X.input_from(0)
W.input_from(1)
Z.input_from(2)
check_point()
challenge=sint.get_random(size=reps*(m+n)).reveal()
check_point()
bits=[]
for t in range(reps):
    u=[challenge[t*(m+n)+i] for i in range(m)]
    r=[challenge[t*(m+n)+m+j] for j in range(n)]
    left=[sum(u[i]*X[i][p] for i in range(m)) for p in range(k)]
    right=[sum(W[p][j]*r[j] for j in range(n)) for p in range(k)]
    product=sint.dot_product(left,right)
    witness=sum(u[i]*r[j]*Z[i][j] for i in range(m) for j in range(n))
    bits.append((product-witness).equal(0,bit_length=64))
accepted=sintbit.tree_reduce(lambda a,b:a*b,bits).reveal()
check_point()
print_ln('ACCEPT %s',accepted)
""".replace('sintbit.tree_reduce(lambda a,b:a*b,bits)','(bits[0]*bits[1])*(bits[2]*bits[3])').replace('accepted=(bits[0]*bits[1])*(bits[2]*bits[3]).reveal()','accepted=((bits[0]*bits[1])*(bits[2]*bits[3])).reveal()')
(droot/'reference.mpc').write_text(source)
X=[[2**32-1,2,7],[17,2**31,-5]]
W=[[2,3],[2,5],[-7,2**32-1]]
z=[[sum(X[i][p]*W[p][j] for p in range(3))%(2**64) for j in range(2)] for i in range(2)]
def words(a):return ' '.join(str((v+2**63)%(2**64)-2**63) for row in a for v in row)+'\n'
exe=mp/'spdz2k-party.x'
summary={'program_sha256':hashlib.sha256(source.encode()).hexdigest(),'exe_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'dimensions':[2,3,2],'public_challenges':'independent full ring64 random secret values opened after input check, four projection pairs','inputs':{'X':X,'W':W,'Z_true_unsigned':z},'cases':[]}
for j,mutation in enumerate(['none','low_word_error','low_word_only']):
    with tempfile.TemporaryDirectory() as temp:
        work=Path(temp)
        logs=droot/mutation
        logs.mkdir(exist_ok=True)
        pd=work/'Player-Data'
        pd.mkdir()
        src=work/'Programs/Source'
        src.mkdir(parents=True)
        for c in (mp/'Player-Data').iterdir():
            if c.suffix in ('.pem','.key','.0'):shutil.copy(c,pd/c.name)
        (src/'siv_proj.mpc').write_text(source)
        witness=[row.copy() for row in z]
        if mutation=='low_word_error':witness[0][0]^=2**31
        if mutation=='low_word_only':witness=[[v%2**32 for v in row] for row in witness]
        for p,arr in enumerate([X,W,witness,[]]):(pd/f'Input-P{p}-0').write_text(words(arr))
        rc=subprocess.run([sys.executable,str(mp/'compile.py'),'-R','64','siv_proj'],cwd=work,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        (logs/'compile.log').write_text(rc.stdout)
        if rc.returncode: print(rc.stdout[-1600:],flush=True);sys.exit(1)
        fs=[open(logs/f'p{p}.log','w') for p in range(4)]
        ps=[subprocess.Popen([str(exe),str(p),'siv_proj','-N','4','-R','64','-e','-v','-pn',str(34040+j*4),'-b','256'],cwd=work,stdout=fs[p],stderr=subprocess.STDOUT) for p in range(4)]
        start=time.monotonic()
        try:
            for proc in ps:proc.wait(timeout=max(.01,100-(time.monotonic()-start)))
        except subprocess.TimeoutExpired: pass
        finally:
            for proc in ps:
                if proc.poll() is None:proc.kill()
                proc.wait()
            for f in fs:f.close()
        logs0=(logs/'p0.log').read_text()
        res=[r for r in logs0.splitlines() if r.startswith(('ACCEPT','Time =','Global data sent','Fatal','Using SPDZ'))]
        ret=[proc.returncode for proc in ps]
        print(mutation,ret,res,flush=True)
        entry={'variant':mutation,'party_exit_codes':ret,'measurements':res,'pass_expected':mutation=='none'}
        summary['cases'].append(entry)
        (droot/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
        if any(ret):print(logs0[-1700:],flush=True);sys.exit(1)
