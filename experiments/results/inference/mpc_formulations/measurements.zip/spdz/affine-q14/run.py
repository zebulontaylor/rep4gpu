from pathlib import Path
import hashlib,json,shutil,subprocess,sys,tempfile,time
mp=Path('/home/zeb/Desktop/mp-spdz-toy/MP-SPDZ')
droot=Path(__file__).resolve().parent
source=(droot/'reference.mpc').read_text()
X=[[2**32-1,2,7],[17,2**31,-5]]
W=[[2,3],[2,5],[-7,2**32-1]]
z=[[sum(X[i][p]*W[p][j] for p in range(3))%(2**64) for j in range(2)] for i in range(2)]
def words(a):return ' '.join(str((v+2**63)%(2**64)-2**63) for row in a for v in row)+'\n'
exe=mp/'spdz2k-party.x'
summary={'program_sha256':hashlib.sha256(source.encode()).hexdigest(),'exe_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'dimensions':[2,3,2],'public_challenges':'independent full ring64 random secret values opened after input check, four projection pairs','inputs':{'X':X,'W':W,'Z_true_unsigned':z},'cases':[]}
bias=[7,-3]
def activate(witness):
    def signed32(x):return (x+2**31)%(2**32)-2**31
    return [[max(0,signed32(v+(bias[j]<<14))//2**14) for j,v in enumerate(row)] for row in witness]
output=activate(z)
summary['inputs'].update(bias=bias,expected_output=output)
for j,mutation in enumerate(['none','bad_activation','bad_product_consistent_activation','low_word_only']):
    with tempfile.TemporaryDirectory() as temp:
        work=Path(temp)
        logs=droot/mutation
        logs.mkdir(exist_ok=True)
        pd=work/'Player-Data'
        pd.mkdir()
        src=work/'Programs/Source'
        src.mkdir(parents=True)
        for c in (mp/'Player-Data').iterdir():
            if c.suffix in ('.pem','.key','.0'):shutil.copy(c,pd/c.name)
        (src/'siv_affine_q14.mpc').write_text(source)
        witness=[row.copy() for row in z]
        y=[row.copy() for row in output]
        if mutation=='bad_activation':
            y[1][1]+=1
        if mutation=='bad_product_consistent_activation':
            witness[0][0]^=2**30
            y=activate(witness)
        if mutation=='low_word_only':
            witness=[[v%2**32 for v in row] for row in witness]
        for p,arr in enumerate([X,W+[bias],witness+y,[]]):(pd/f'Input-P{p}-0').write_text(words(arr))
        rc=subprocess.run([sys.executable,str(mp/'compile.py'),'-R','64','siv_affine_q14'],cwd=work,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        (logs/'compile.log').write_text(rc.stdout)
        if rc.returncode: print(rc.stdout[-1600:],flush=True);sys.exit(1)
        fs=[open(logs/f'p{p}.log','w') for p in range(4)]
        ps=[subprocess.Popen([str(exe),str(p),'siv_affine_q14','-N','4','-R','64','-e','-v','-pn',str(35640+j*4),'-b','256'],cwd=work,stdout=fs[p],stderr=subprocess.STDOUT) for p in range(4)]
        start=time.monotonic()
        try:
            for proc in ps:proc.wait(timeout=max(.01,100-(time.monotonic()-start)))
        except subprocess.TimeoutExpired: pass
        finally:
            for proc in ps:
                if proc.poll() is None:proc.kill()
                proc.wait()
            for f in fs:f.close()
        logs0=(logs/'p0.log').read_text()
        res=[r for r in logs0.splitlines() if r.startswith(('ACCEPT','Time =','Global data sent','Fatal','Using SPDZ'))]
        ret=[proc.returncode for proc in ps]
        print(mutation,ret,res,flush=True)
        entry={'variant':mutation,'submitted_output':y,'submitted_Z':witness,'party_exit_codes':ret,'measurements':res,'pass_expected':mutation=='none'}
        summary['cases'].append(entry)
        (droot/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
        if any(ret) or ('ACCEPT '+str(int(mutation=='none'))) not in res:print(logs0[-1700:],flush=True);sys.exit(1)
