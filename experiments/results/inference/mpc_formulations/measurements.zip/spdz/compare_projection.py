import hashlib,json,re,shutil,subprocess,sys,tempfile,time
from pathlib import Path
import numpy as np
mp=Path('/home/zeb/Desktop/mp-spdz-toy/MP-SPDZ')
out=Path('/tmp/siv-research-3pc/compare-projection')
out.mkdir(exist_ok=True)
observations=[]
for case,(m,k,n) in enumerate([(4,8,4),(8,16,8),(16,32,16)]):
    for t in range(4):
        mode=['direct','project','project','direct'][t]
        dst=out/f'{m}x{k}x{n}-{t}-{mode}'
        dst.mkdir(exist_ok=True)
        head=f"""from Compiler.library import check_point,print_ln,start_timer,stop_timer
from Compiler.types import sint
m,k,n={m},{k},{n}
reps=4
X=sint.Matrix(m,k)
WT=sint.Matrix(n,k)
Z=sint.Matrix(m,n)
X.input_from(0)
WT.input_from(1)
Z.input_from(2)
check_point()
challenge=sint.get_random(size=reps*(m+n)).reveal()
check_point()
start_timer(1)
"""
        direct="""full=X.direct_mul_trans(WT)
"""
        common="""bits=[]
for t in range(reps):
    u=[challenge[t*(m+n)+i] for i in range(m)]
    r=[challenge[t*(m+n)+m+j] for j in range(n)]
"""
        body1="""    residual=sum(u[i] * r[j] * (full[i*n+j]-Z[i][j]) for i in range(m) for j in range(n))
"""
        body2="""    left=[sum(u[i]*X[i][p] for i in range(m)) for p in range(k)]
    right=[sum(WT[j][p]*r[j] for j in range(n)) for p in range(k)]
    product=sint.dot_product(left,right)
    witness=sum(u[i]*r[j]*Z[i][j] for i in range(m) for j in range(n))
    residual=product-witness
"""
        tail="""    bits.append(residual.equal(0,bit_length=64))
accepted=((bits[0]*bits[1])*(bits[2]*bits[3])).reveal()
check_point()
stop_timer(1)
print_ln('ACCEPT %s',accepted)
"""
        source=head+(direct if mode=='direct' else '')+common+(body1 if mode=='direct' else body2)+tail
        (dst/'reference.mpc').write_text(source)
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp)
            pd=d/'Player-Data'
            pd.mkdir()
            src=d/'Programs/Source'
            src.mkdir(parents=True)
            for c in (mp/'Player-Data').iterdir():
                if c.suffix in ('.pem','.key','.0'):shutil.copy(c,pd/c.name)
            (src/'siv_compare.mpc').write_text(source)
            rng=np.random.default_rng(994)
            x=rng.integers(0,2**32,(m,k),dtype=np.uint64)
            wt=rng.integers(0,2**32,(n,k),dtype=np.uint64)
            z=x@wt.T
            for p,arr in enumerate((x,wt,z)):np.savetxt(pd/f'Input-P{p}-0',arr.view(np.int64).reshape(-1),fmt='%d')
            (pd/'Input-P3-0').write_text('')
            rc=subprocess.run([sys.executable,str(mp/'compile.py'),'-R','64','siv_compare'],cwd=d,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            (dst/'compile.log').write_text(rc.stdout)
            if rc.returncode: print(rc.stdout[-2000:],flush=True);sys.exit(1)
            logs=[open(dst/f'p{p}.log','w') for p in range(4)]
            ps=[subprocess.Popen([str(mp/'spdz2k-party.x'),str(p),'siv_compare','-N','4','-R','64','-e','-v','-pn',str(34440+case*24+t*4),'-b','256'],cwd=d,stdout=logs[p],stderr=subprocess.STDOUT) for p in range(4)]
            start=time.monotonic()
            try:
                for proc in ps:proc.wait(timeout=max(.01,100-(time.monotonic()-start)))
            except subprocess.TimeoutExpired:pass
            finally:
                for proc in ps:
                    if proc.poll() is None:proc.kill()
                    proc.wait()
                for f in logs:f.close()
            codes=[p.returncode for p in ps]
            s=(dst/'p0.log').read_text()
            if any(codes) or 'ACCEPT 1' not in s:
                print(s[-1800:],flush=True)
                sys.exit(1)
            time1=re.search(r'(?m)^Time1 = (\S+) seconds \((\S+) MB, (\d+) rounds',s)
            obs=dict(shape=[m,k,n],mode=mode,trial=t,codes=codes,valid=True,total_seconds=float(re.search(r'(?m)^Time = (\S+) seconds',s)[1]),global_MB=float(re.search(r'(?m)^Global data sent = (\S+) MB',s)[1]),checked_interval_seconds=float(time1[1]),interval_party0_MB=float(time1[2]),interval_party0_rounds=int(time1[3]))
            print(obs,flush=True)
            observations.append(obs)
            (out/'observations.json').write_text(json.dumps(observations,indent=2)+'\n')
